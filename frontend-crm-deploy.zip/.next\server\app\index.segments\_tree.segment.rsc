:HL["/_next/static/chunks/0ni3y1_bhdk0m.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}},"staleTime":300,"buildId":"x57bDdkEX7Jw8iwLPmOEE"}
