globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/tpV-XIkfYW74JnTsJbxXV/_buildManifest.js",
    "static/tpV-XIkfYW74JnTsJbxXV/_ssgManifest.js",
    "static/tpV-XIkfYW74JnTsJbxXV/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ze4gu236oq96.js",
    "static/chunks/09c-quirf_8o2.js",
    "static/chunks/0n~dq4kpx9xxx.js",
    "static/chunks/0qtz4meecy2cb.js",
    "static/chunks/0ndo9gs9bq1e1.js",
    "static/chunks/turbopack-0eru2qq7ia-4-.js"
  ]
};
