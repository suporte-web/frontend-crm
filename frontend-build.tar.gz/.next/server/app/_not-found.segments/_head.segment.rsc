1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/09zecdrwdq8ej.js","/_next/static/chunks/0h37628qgz3y1.js","/_next/static/chunks/0~lv3rjm3nz7y.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/09zecdrwdq8ej.js","/_next/static/chunks/0h37628qgz3y1.js","/_next/static/chunks/0~lv3rjm3nz7y.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"CRM Portal"}],["$","meta","1",{"name":"description","content":"Portal comercial multi-cliente"}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"tpV-XIkfYW74JnTsJbxXV"}
