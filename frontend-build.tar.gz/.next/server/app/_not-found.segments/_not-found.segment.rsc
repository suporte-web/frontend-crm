1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/09zecdrwdq8ej.js","/_next/static/chunks/0h37628qgz3y1.js","/_next/static/chunks/0~lv3rjm3nz7y.js"],"default"]
3:I[37457,["/_next/static/chunks/09zecdrwdq8ej.js","/_next/static/chunks/0h37628qgz3y1.js","/_next/static/chunks/0~lv3rjm3nz7y.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"tpV-XIkfYW74JnTsJbxXV"}
