1:"$Sreact.fragment"
3:I[97367,["/_next/static/chunks/09zecdrwdq8ej.js","/_next/static/chunks/0h37628qgz3y1.js","/_next/static/chunks/0~lv3rjm3nz7y.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"tpV-XIkfYW74JnTsJbxXV"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/entrar;307;"}
