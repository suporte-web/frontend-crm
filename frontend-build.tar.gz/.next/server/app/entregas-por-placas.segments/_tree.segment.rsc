:HL["/_next/static/chunks/0bfifc5a4ffbv.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"entregas-por-placas","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"tpV-XIkfYW74JnTsJbxXV"}
