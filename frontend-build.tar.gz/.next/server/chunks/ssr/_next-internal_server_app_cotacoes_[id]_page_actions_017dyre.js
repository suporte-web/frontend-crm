module.exports=[18844,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_cotacoes_%5Bid%5D_page_actions_017dyre.js.map