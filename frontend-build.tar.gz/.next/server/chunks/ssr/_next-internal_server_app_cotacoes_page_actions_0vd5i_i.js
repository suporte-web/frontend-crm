module.exports=[85421,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_cotacoes_page_actions_0vd5i_i.js.map