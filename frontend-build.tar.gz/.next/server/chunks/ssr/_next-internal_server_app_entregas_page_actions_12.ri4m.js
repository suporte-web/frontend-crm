module.exports=[94008,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_entregas_page_actions_12.ri4m.js.map