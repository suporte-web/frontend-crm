module.exports=[76363,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_solicitacoes-site_page_actions_0j.15ak.js.map