module.exports=[81541,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_fornecedores_page_actions_08r_7u-.js.map