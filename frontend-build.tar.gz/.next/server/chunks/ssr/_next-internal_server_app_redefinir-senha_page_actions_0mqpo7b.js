module.exports=[65569,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_redefinir-senha_page_actions_0mqpo7b.js.map