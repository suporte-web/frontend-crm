module.exports=[52227,(a,b,c)=>{}];

//# sourceMappingURL=0zjb_server_app_clientes_%5Bid%5D_propostas_%5BpropostaId%5D_page_actions_0tcceh8.js.map