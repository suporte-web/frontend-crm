module.exports=[21049,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_chamados_page_actions_0ix1yjz.js.map