module.exports=[43333,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_entregas-por-placas_page_actions_06k-8ps.js.map