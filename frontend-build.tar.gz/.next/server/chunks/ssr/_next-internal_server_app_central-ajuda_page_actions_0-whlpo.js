module.exports=[46429,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_central-ajuda_page_actions_0-whlpo.js.map