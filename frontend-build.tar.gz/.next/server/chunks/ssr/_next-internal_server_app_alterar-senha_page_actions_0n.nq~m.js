module.exports=[21808,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_alterar-senha_page_actions_0n.nq~m.js.map