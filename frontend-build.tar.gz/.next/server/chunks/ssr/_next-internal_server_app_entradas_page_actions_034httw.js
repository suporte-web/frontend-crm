module.exports=[23962,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_entradas_page_actions_034httw.js.map