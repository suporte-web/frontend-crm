module.exports=[17149,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_entradas_%5Bid%5D_page_actions_0q8cuih.js.map