module.exports=[99320,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bi_page_actions_0dg1fb_.js.map