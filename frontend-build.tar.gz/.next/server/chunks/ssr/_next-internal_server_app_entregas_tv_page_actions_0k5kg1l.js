module.exports=[58902,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_entregas_tv_page_actions_0k5kg1l.js.map