1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/0rlswdcp6-rfo.js","/_next/static/chunks/0f_50n4i0rp0q.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/0rlswdcp6-rfo.js","/_next/static/chunks/0f_50n4i0rp0q.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"CRM Portal"}],["$","meta","1",{"name":"description","content":"Portal comercial multi-cliente"}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"s0dE-QD11WBwAH72tVvF4"}
