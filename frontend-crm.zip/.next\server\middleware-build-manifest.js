globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/s0dE-QD11WBwAH72tVvF4/_buildManifest.js",
    "static/s0dE-QD11WBwAH72tVvF4/_ssgManifest.js",
    "static/s0dE-QD11WBwAH72tVvF4/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ze4gu236oq96.js",
    "static/chunks/17wq3e1_d1bu7.js",
    "static/chunks/0n~dq4kpx9xxx.js",
    "static/chunks/0qtz4meecy2cb.js",
    "static/chunks/0ndo9gs9bq1e1.js",
    "static/chunks/turbopack-0a.5ivytijw1q.js"
  ]
};
